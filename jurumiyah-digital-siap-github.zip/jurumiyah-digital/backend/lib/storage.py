import os
import threading

import requests


STORAGE_BASE = (os.environ.get("INTEGRATION_PROXY_URL") or "").strip() or "https://integrations.emergentagent.com"
STORAGE_URL = STORAGE_BASE.rstrip("/") + "/objstore/api/v1/storage"
EMERGENT_KEY = os.environ.get("EMERGENT_LLM_KEY")

_storage_key: str | None = None
_storage_lock = threading.Lock()


def init_storage(force: bool = False) -> str:
    global _storage_key
    with _storage_lock:
        if _storage_key and not force:
            return _storage_key
        if not EMERGENT_KEY:
            raise RuntimeError("EMERGENT_LLM_KEY belum dikonfigurasi")
        response = requests.post(
            f"{STORAGE_URL}/init",
            json={"emergent_key": EMERGENT_KEY},
            timeout=30,
        )
        response.raise_for_status()
        _storage_key = response.json()["storage_key"]
        return _storage_key


def _object_request(method: str, path: str, **kwargs) -> requests.Response:
    key = init_storage()
    response = requests.request(
        method,
        f"{STORAGE_URL}/objects/{path}",
        headers={**kwargs.pop("headers", {}), "X-Storage-Key": key},
        **kwargs,
    )
    if response.status_code == 404:
        key = init_storage(force=True)
        response = requests.request(
            method,
            f"{STORAGE_URL}/objects/{path}",
            headers={**kwargs.pop("headers", {}), "X-Storage-Key": key},
            **kwargs,
        )
    response.raise_for_status()
    return response


def put_object(path: str, data: bytes, content_type: str) -> dict:
    response = _object_request(
        "PUT",
        path,
        headers={"Content-Type": content_type},
        data=data,
        timeout=120,
    )
    return response.json()


def get_object(path: str) -> tuple[bytes, str]:
    response = _object_request("GET", path, timeout=60)
    return response.content, response.headers.get("Content-Type", "application/octet-stream")
