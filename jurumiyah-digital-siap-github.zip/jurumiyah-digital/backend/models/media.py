from datetime import datetime
from pydantic import BaseModel, Field


class MediaAsset(BaseModel):
    id: str
    original_filename: str
    content_type: str
    size: int
    category: str
    description: str = ""
    created_at: datetime


class MediaUploadResponse(BaseModel):
    asset: MediaAsset
    message: str = "File berhasil diunggah"


class MediaDeleteResponse(BaseModel):
    id: str
    deleted: bool = True
    message: str = "File berhasil dihapus dari daftar publik"


class StorageStatus(BaseModel):
    configured: bool
    allowed_extensions: list[str] = Field(default_factory=list)
    max_size_mb: int
