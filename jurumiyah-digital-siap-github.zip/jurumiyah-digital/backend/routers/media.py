import asyncio
import os
import re
import uuid
from datetime import datetime, timezone
from pathlib import Path

from fastapi import APIRouter, File, Form, Header, HTTPException, UploadFile
from fastapi.responses import Response

from lib.db import db
from lib.storage import get_object, put_object
from models.media import MediaAsset, MediaDeleteResponse, MediaUploadResponse, StorageStatus


router = APIRouter(prefix="/media", tags=["media"])

MAX_FILE_SIZE = 25 * 1024 * 1024
ALLOWED_EXTENSIONS = {"zip", "pdf", "png", "jpg", "jpeg", "webp", "mp3", "wav", "json", "md"}
ALLOWED_CONTENT_TYPES = {
    "application/zip",
    "application/x-zip-compressed",
    "application/pdf",
    "image/png",
    "image/jpeg",
    "image/webp",
    "audio/mpeg",
    "audio/wav",
    "audio/x-wav",
    "application/json",
    "text/markdown",
    "text/plain",
    "application/octet-stream",
}
APP_PREFIX = "jurumiyah-digital"


def require_admin(admin_pin: str | None) -> None:
    expected = os.environ.get("MEDIA_ADMIN_PIN")
    if not expected or not admin_pin or admin_pin != expected:
        raise HTTPException(status_code=401, detail="PIN admin tidak valid")


def normalize_datetime(value: datetime) -> datetime:
    return value.replace(tzinfo=timezone.utc) if value.tzinfo is None else value


def to_asset(document: dict) -> MediaAsset:
    return MediaAsset(
        id=document["id"],
        original_filename=document["original_filename"],
        content_type=document["content_type"],
        size=document["size"],
        category=document["category"],
        description=document.get("description", ""),
        created_at=normalize_datetime(document["created_at"]),
    )


@router.get("/status", response_model=StorageStatus)
async def storage_status():
    return StorageStatus(
        configured=bool(os.environ.get("EMERGENT_LLM_KEY") and os.environ.get("MEDIA_ADMIN_PIN")),
        allowed_extensions=sorted(ALLOWED_EXTENSIONS),
        max_size_mb=MAX_FILE_SIZE // (1024 * 1024),
    )


@router.get("", response_model=list[MediaAsset])
async def list_media():
    documents = await db.media_assets.find({"is_deleted": False}).sort("created_at", -1).to_list(1000)
    return [to_asset(document) for document in documents]


@router.post("/upload", response_model=MediaUploadResponse, status_code=201)
async def upload_media(
    file: UploadFile = File(...),
    category: str = Form("asset"),
    description: str = Form(""),
    x_admin_pin: str | None = Header(default=None),
):
    require_admin(x_admin_pin)
    original_filename = Path(file.filename or "file.bin").name
    extension = original_filename.rsplit(".", 1)[-1].lower() if "." in original_filename else ""
    content_type = file.content_type or "application/octet-stream"
    if extension not in ALLOWED_EXTENSIONS or content_type not in ALLOWED_CONTENT_TYPES:
        raise HTTPException(status_code=415, detail="Jenis file tidak diizinkan")
    if category not in {"source", "kitab", "image", "audio", "asset"}:
        raise HTTPException(status_code=422, detail="Kategori file tidak valid")
    data = await file.read(MAX_FILE_SIZE + 1)
    if not data:
        raise HTTPException(status_code=422, detail="File tidak boleh kosong")
    if len(data) > MAX_FILE_SIZE:
        raise HTTPException(status_code=413, detail="Ukuran file melebihi 25 MB")
    safe_extension = re.sub(r"[^a-z0-9]", "", extension) or "bin"
    storage_path = f"{APP_PREFIX}/uploads/admin/{uuid.uuid4()}.{safe_extension}"
    result = await asyncio.to_thread(put_object, storage_path, data, content_type)
    created_at = datetime.now(timezone.utc)
    document = {
        "id": str(uuid.uuid4()),
        "storage_path": result["path"],
        "original_filename": original_filename,
        "content_type": content_type,
        "size": result.get("size", len(data)),
        "category": category,
        "description": description.strip()[:300],
        "is_deleted": False,
        "created_at": created_at,
    }
    await db.media_assets.insert_one(document)
    return MediaUploadResponse(asset=to_asset(document))


@router.get("/{media_id}/download")
async def download_media(media_id: str):
    document = await db.media_assets.find_one({"id": media_id, "is_deleted": False})
    if not document:
        raise HTTPException(status_code=404, detail="File tidak ditemukan")
    data, detected_content_type = await asyncio.to_thread(get_object, document["storage_path"])
    filename = document["original_filename"].replace('"', "")
    return Response(
        content=data,
        media_type=document.get("content_type") or detected_content_type,
        headers={"Content-Disposition": f'inline; filename="{filename}"'},
    )


@router.delete("/{media_id}", response_model=MediaDeleteResponse)
async def delete_media(media_id: str, x_admin_pin: str | None = Header(default=None)):
    require_admin(x_admin_pin)
    result = await db.media_assets.update_one(
        {"id": media_id, "is_deleted": False},
        {"$set": {"is_deleted": True, "deleted_at": datetime.now(timezone.utc)}},
    )
    if result.modified_count == 0:
        raise HTTPException(status_code=404, detail="File tidak ditemukan")
    return MediaDeleteResponse(id=media_id)
