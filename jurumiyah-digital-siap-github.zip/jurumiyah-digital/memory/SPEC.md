# Jurumiyah Digital

## Status
Versi pertama adalah aplikasi pembelajaran dengan progress lokal dan Emergent Object Storage untuk source ZIP serta aset kitab.

## Fitur utama
- Beranda dengan progress belajar dan tombol lanjutkan dari bab terakhir.
- Kata Pengantar dengan naskah yang diberikan pengguna dan watermark Kang Alexx.
- Daftar Isi 29 bab, pencarian judul/istilah, dan tautan langsung ke reader.
- Reader responsif dengan sidebar bab, pencarian, bab sebelumnya/berikutnya, bookmark, tandai selesai, mode terang/gelap, serta pengaturan ukuran teks Arab dan terjemahan.
- Tentang project dengan sumber publik, penjelasan tujuan, dan tautan unduh ZIP.
- Pustaka Media publik untuk melihat/mengunduh source ZIP, PDF, gambar, dan audio.
- Panel `/admin/media` untuk upload serta soft-delete file menggunakan PIN admin dari environment.

## Data kitab
Data berada di `frontend/src/data/jurumiyah.ts`. Bab 1–4 berisi teks matan awal yang ditandai terverifikasi dari Wikisource. Bab 5–29 hanya berupa struktur daftar isi dan tidak menampilkan teks rekaan; data asli dapat ditambahkan kemudian pada file yang sama.

## Penyimpanan
Progress, bookmark, bab terakhir, tema, dan ukuran font tersimpan di localStorage dengan key `jurumiyah-digital-learning`.

Metadata file disimpan pada collection MongoDB `media_assets`; binary disimpan di Emergent Object Storage dengan prefix `jurumiyah-digital/uploads/admin`. Pengunjung dapat list/download. Upload/delete memerlukan header `X-Admin-Pin`. Delete bersifat soft-delete karena layanan storage tidak memiliki delete object.

## Alur inti
Beranda → Kata Pengantar / Daftar Isi → pilih bab → teks kitab (jika tersedia) → terjemahan → penjelasan → contoh → i'rab → tandai selesai → bab berikutnya.

Admin media: `/admin/media` → masukkan PIN → pilih file/kategori → upload → file tampil di `/media` → pengunjung mengunduh melalui backend.
