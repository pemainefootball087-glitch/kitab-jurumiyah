export interface ExampleEntry {
  arabic: string;
  translation: string;
  note?: string;
}

export interface IrabEntry {
  lafadz: string;
  position: string;
  sign: string;
  reason: string;
}

export interface Chapter {
  id: string;
  number: number;
  titleArabic: string;
  titleIndonesia: string;
  summary: string;
  status: "verified" | "ready";
  sourceTitle?: string;
  matn?: string;
  translation?: string;
  explanation?: string;
  examples?: ExampleEntry[];
  irab?: IrabEntry[];
  note?: string;
  terms: string[];
}

export const SOURCE_URL =
  "https://ar.wikisource.org/wiki/الآجرومية_في_قواعد_علم_العربية";

const readySummary =
  "Struktur bab sudah disiapkan. Teks matan asli akan dimasukkan setelah proses penyuntingan sumber selesai.";

export const CHAPTERS: Chapter[] = [
  {
    id: "kalam",
    number: 1,
    titleArabic: "الكَلَامُ وَأَقْسَامُهُ",
    titleIndonesia: "Kalam dan Pembagiannya",
    summary: "Mengenal definisi kalam serta tanda-tanda isim, fi'il, dan huruf.",
    status: "verified",
    sourceTitle: "الكلام وأقسامه",
    matn:
      "الكَلَامُ هُوَ اللَّفْظُ المُر��كَّبُ المُفِيدُ بِالوَضْعِ. وأَقْسَامُه ثَلَاثَةُ إسْمٌ وفعْلٌ وحَرْفٌ جَاءَ لِمَعْنَّى. فالإِسْم يُعْرَفُ بِالخَفْضِ والتَّنْوِينِ ودُخُولِ الأَلفِ واللَّامِ وحُرُوفِ الخْفَضِ وهِيَ مِنْ وإِلَى وعَنْ وعلى وفِي ورُبَّ والبَاءُ والكَافُ والَّلامُ وحُرُوفِ القَسَمِ وهِيَ الوَاوُ والبَاءُ والتَّاءُ. والفِعْلِ يُعْرَفُ بِقَدْ والسين وسَوْفَ وتَاءِ التَّأْنِيثِ السَّاكِنَةِ والحَرّفُ مَا لَا يَصلُحُ مَعَهُ دَليلُ الإِسْمِ ولَا دَلِيلُ الفِعْلِ.",
    translation:
      "Kalam adalah lafaz yang tersusun, memberi faedah, dan digunakan menurut ketetapan bahasa. Kalam terbagi menjadi tiga: isim, fi'il, dan huruf yang memiliki makna. Isim dikenali dengan jar, tanwin, masuknya alif-lam, serta huruf jar dan huruf sumpah. Fi'il dikenali dengan قد, سـ, سوف, dan ta' ta'nits yang sukun. Huruf adalah kata yang tidak menerima tanda isim maupun tanda fi'il.",
    explanation:
      "Bab ini menjadi pintu masuk ilmu Nahwu. Sebelum menganalisis kedudukan sebuah kata, kita perlu mengenali jenis katanya. Isim biasanya menunjuk benda, orang, atau makna; fi'il menunjukkan pekerjaan yang terikat waktu; sedangkan huruf menghubungkan makna dengan kata lain.",
    examples: [
      { arabic: "جَاءَ زَيْدٌ", translation: "Zaid telah datang.", note: "زَيْدٌ adalah isim karena menerima dhammah dan tanwin." },
      { arabic: "قَدْ قَامَ زَيْدٌ", translation: "Sungguh Zaid telah berdiri.", note: "قَدْ menjadi salah satu tanda yang masuk pada fi'il." },
      { arabic: "مَرَرْتُ بِزَيْدٍ", translation: "Aku melewati Zaid.", note: "بِ adalah huruf jar, sedangkan زَيْدٍ menjadi majrur." },
    ],
    irab: [
      { lafadz: "زَيْدٌ", position: "فَاعِلٌ", sign: "ضَمَّةٌ", reason: "Isim mufrad yang menjadi pelaku pekerjaan." },
      { lafadz: "بِزَيْدٍ", position: "اسْمٌ مَجْرُورٌ", sign: "كَسْرَةٌ", reason: "Didahului huruf jar بِ." },
    ],
    note: "Bedakan antara jenis kata (isim, fi'il, huruf) dan kedudukan kata dalam kalimat. Keduanya adalah pembahasan yang berbeda.",
    terms: ["isim", "fiil", "huruf", "kalam", "tanda isim", "tanda fi'il"],
  },
  {
    id: "irab",
    number: 2,
    titleArabic: "بَابُ الإِعْرَابِ",
    titleIndonesia: "I'rab",
    summary: "Memahami perubahan akhir kata karena perbedaan amil yang memasukinya.",
    status: "verified",
    sourceTitle: "باب الإعراب",
    matn:
      "الإعْرَابُ هُوَ تَغْيِيرُ أَوَاخِرِ الكَلمِ لِاخْتِلَافِ العَوَامِلِ الدَّاخلةِ عَليْهَا لَفْظًا أوْ تَقْدِيرًا. وَأَقْسَامْهُ أَرْبَعَةٌ رَفْعٌ ونَصْبٌ وخَفْضٌ وَجَزْمٌ. فَلِلْأَسْمَاءِ مِنْ ذَلِكَ الرَّفعُ والنَّصْبُ والخَفْضُ ولَا جَزْمَ فِيهَا. وللأَفْعَالِ من ذلِكَ الرَّفْعُ والنَّصْبُ والجَزْم ولَا خَفْضَ فِيها.",
    translation:
      "I'rab adalah perubahan akhir kata karena perbedaan amil yang masuk kepadanya, baik perubahan yang tampak maupun yang diperkirakan. I'rab terbagi menjadi empat: rafa', nashab, jar, dan jazm. Isim dapat mengalami rafa', nashab, dan jar, tetapi tidak mengalami jazm. Fi'il dapat mengalami rafa', nashab, dan jazm, tetapi tidak mengalami jar.",
    explanation:
      "Akhir kata dalam bahasa Arab tidak selalu tetap. Perubahan harakat akhir memberi petunjuk tentang hubungan kata tersebut dengan kata lain. Karena itu, i'rab membantu pembaca memahami siapa pelaku, objek, atau keterangan dalam sebuah kalimat.",
    examples: [
      { arabic: "جَاءَ زَيْدٌ", translation: "Zaid datang.", note: "زَيْدٌ marfu' karena menjadi fa'il." },
      { arabic: "رَأَيْتُ زَيْدًا", translation: "Aku melihat Zaid.", note: "زَيْدًا manshub karena menjadi maf'ul bih." },
      { arabic: "مَرَرْتُ بِزَيْدٍ", translation: "Aku melewati Zaid.", note: "زَيْدٍ majrur karena didahului بِ." },
    ],
    irab: [
      { lafadz: "زَيْدٌ", position: "فَاعِلٌ مَرْفُوعٌ", sign: "ضَمَّةٌ ظَاهِرَةٌ", reason: "Karena isim menjadi pelaku dan tidak didahului amil nashab atau jar." },
      { lafadz: "زَيْدًا", position: "مَفْعُولٌ بِهِ مَنْصُوبٌ", sign: "فَتْحَةٌ ظَاهِرَةٌ", reason: "Karena pekerjaan melihat jatuh pada objek." },
    ],
    note: "Empat istilah utama bab ini: رفع untuk marfu', نصب untuk manshub, خفض/جر untuk majrur, dan جزم untuk majzum.",
    terms: ["i'rab", "rafa", "nashab", "jar", "jazm", "amil"],
  },
  {
    id: "alamat-irab",
    number: 3,
    titleArabic: "بَابُ مَعْرِفَةِ عَلَامَاتِ الإِعْرَابِ",
    titleIndonesia: "Tanda-Tanda I'rab",
    summary: "Mengenali tanda asli dan pengganti untuk rafa', nashab, jar, dan jazm.",
    status: "verified",
    sourceTitle: "باب معرفة علامات الإعراب",
    matn:
      "للرَّفْعِ أرْبَعُ عَلَاماتٍ. الضَّمَّةُ وَالوَاوُ والأَلِفُ وَالنُّونُ. فأَمَّا الضَّمَّةُ فَتكُونُ عَلَامَةً لِلرَّفْع في أَرْبَعَةِ مَوَاضعَ في الإِسمِ المُفْرَدِ وجَمْعِ التَّكْسيِرِ وجَمْعِ المُؤّنَّثِ السَّالِمِ والفِعْلِ المُضارعِ الذَّي لَمْ يَتَّصِلْ بآخرِهِ شيء. وأَمَّا الوَاوُ فَتَكُونُ عَلَامَةَ لِلرَّفع في مَوْضِعَيْنِ في جَمعِ المْذَكَّرِ السالِمِ وفي الأَسْمَاء الخَمْسَةِ وهِيَ أبُوكَ وَأخُوكَ وحَمَوكَ وفُوكَ وذو مال. وأمَّا الأَلف فَتَكْونُ عَلَامَة للرَّفْع في تَثْنِيَةِ الأَسْماءِ خاصَّة. وأَمَّا النُّونُ فَتكُونُ عَلَامة للرَّفْع في الفعْلِ المُضَارعِ إذا اتَّصَلَ بهِ ضميرُ تَثْنيةٍ أوْ ضَمِيرُ جمْع أوْ ضَميرُ المُؤَنَّثَةِ المُخَاطَبةِ. وللنَّصْبِ خَمْسُ عَلَامات الفتْحة والأَلفُ والكَسْرَة واليَاء وحَذْف النَّونِ. فأَمَّا الفتْحَةُ فَتَكُونُ عَلَامَةَ لِلنَّصْبِ في ثَلَاثَةِ موَاضِعَ في الإِسْمِ المفْرَدِ وجَمْع التَّكْسير والفِعْلِ المُضَارِعِ إذا دَخَلَ عَلَيْهِ ناصِبٌ ولَمْ يَتَّصِل بآخِرِهِ شيْءٌ. وأمَّا الأَلفُ فَتَكُونُ عَلَامَةَ لِلنَّصْبِ في الأَسْماءِ الخَمْسَةِ نَحْوُ رَأَيْتُ أبَاكَ وأخاكَ ومَا أَشْبَهَ ذلِكَ. وأمَّا الكَسْرَةُ فَتَكونُ عَلَامَةَ للنَّصْبِ في جَمْعِ المُؤَنَّثِ السَّالِ��ِ. وأمَّا اليَاءُ فَتَكُونُ عَلَامَةً لِلنَّصْبِ في التَّثْنيةِ والجَمْعِ. وأمَّا حَذْف النَّونِ فَيَكُونُ عَلَامَةً لِلنَّصْبِ في الأَفْعَالِ الخَمْسَةِ الَّتِي رَفْعها بثبات النُّون. وللخَفْضِ ثَلَاثُ علَاماتِ الكَسْرَةُ واليَاءُ والفَتْحَةُ. فَأمَّا الكَسْرَةُ فَتَكُون​علَامَةً لِلخَفْضِ في ثلَاثَةِ مَوَاضعَ فِي الإِسْمِ المُفْرَدِ وجَمْعِ التَّكْسير المُنْصَرِفِ وجَمَعِ المُؤَنَّثِ السَّالِمِ. وأَمَّا الياءُ فَتَكُونُ علامَةً لِلخَفْضِ فِي ثلاثَةِ مَوَاضع فِي الأَسْماءِ الخمسة وَفِي التَّثْنيةِ والجَمْعِ. وأَمَّا الفَتْحَةُ فَتَكْونُ عَلَامَةَ لِلخَفْضِ فِي الإِسْمِ الَّذِي لا بنْصرِف. ولِلْجَزْمِ عَلامتانِ السكون والحذف. فأَمَّا السكون فيكون علامة للجزم فِي الفعْلِ المُضارع الصحيح الآخر. وأَمَّا الحذْف فَيكونُ علَامةً لِلجزمِ فِي الفعل المضارِعِ المعنلِّ الآخرِ وَفِي الأفعال الخَمْسَةِ الَّتي رَفْعها بثَبَاتِ النُّون.",
    translation:
      "Rafa' memiliki empat tanda: dhammah, waw, alif, dan nun. Nashab memiliki lima tanda: fathah, alif, kasrah, ya, dan membuang nun. Jar memiliki tiga tanda: kasrah, ya, dan fathah. Jazm memiliki dua tanda: sukun dan membuang huruf.",
    explanation:
      "Dhammah, fathah, kasrah, dan sukun adalah tanda yang paling sering ditemui. Namun, beberapa bentuk kata memakai huruf sebagai tanda pengganti, misalnya waw pada jamak mudzakkar salim dan alif pada mutsanna.",
    examples: [
      { arabic: "جَاءَ المُعَلِّمُونَ", translation: "Para guru datang.", note: "Waw menjadi tanda rafa' pada jamak mudzakkar salim." },
      { arabic: "رَأَيْتُ المُعَلِّمِينَ", translation: "Aku melihat para guru.", note: "Ya menjadi tanda nashab pada jamak mudzakkar salim." },
      { arabic: "لَمْ يَذْهَبْ", translation: "Ia tidak pergi.", note: "Sukun menjadi tanda jazm pada fi'il mudhari' yang shahih akhirnya." },
    ],
    irab: [
      { lafadz: "المُعَلِّمُونَ", position: "فَاعِلٌ مَرْفُوعٌ", sign: "وَاوٌ", reason: "Termasuk jamak mudzakkar salim." },
      { lafadz: "المُعَلِّمِينَ", position: "مَفْعُولٌ بِهِ مَنْصُوبٌ", sign: "يَاءٌ", reason: "Termasuk jamak mudzakkar salim yang manshub." },
    ],
    note: "Satu tanda dapat menjadi tanda untuk lebih dari satu keadaan. Perhatikan bentuk kata dan kedudukannya sekaligus.",
    terms: ["tanda i'rab", "dhammah", "fathah", "kasrah", "sukun", "waw", "alif", "ya", "nun"],
  },
  {
    id: "afal",
    number: 4,
    titleArabic: "بَابُ الأَفْعَالِ",
    titleIndonesia: "Fi'il",
    summary: "Membedakan fi'il madhi, mudhari', dan amr serta amil yang memengaruhinya.",
    status: "verified",
    sourceTitle: "باب الأفعال",
    matn:
      "الأفعالُ ثلاثة ماضٍ ومُضارعٌ وأمر نحو ضَرَبَ ويَضرِبُ واضرِبْ. فالماضي مَفْتُوحُ الآخِرِ أبدا. والأَمْرُ مَجْزُومٌ أبَداً. والمُضَارِعُ ما كان في أوله إحْدَى الزَّوَائِدِ الأَرْبعِ يجمَعُهَا قولُك أنَيتُ وهو مرفوعٌ أبداً حتَّى يَدْخُلَ عَليهِ ناصِبٌ أَوْ جازِمٌ فالنَّوَاصِبُ عَشَرَة وَهي أَنْ وَلَنْ وَإِذنْ وَكَيْ ولامُ كي ولامُ الجُحُودِ وحتَّى والجَوَابُ بالفَاءِ وَالوَاوِ وَأَو. والجوازِمُ ثمانيةَ عَشَرَ وهي لَمْ ولَمَّا وألَمْ وألَمَّا ولام الأَمْرِ والدُّعاء ولا في النَّهْيِ والدُّعاءِ وإِنْ وما ومَنْ ومَهْمَا وَإِذْما وَأَيُّ وَمَتى وَأَيَّانَ وَأَيْنَ وَأَنَّى وحَيثُمَا وَكَيْفَما وإذا في الشِّعر خاصَّة.",
    translation:
      "Fi'il terbagi menjadi tiga: madhi, mudhari', dan amr; contohnya ضَرَبَ, يَضْرِبُ, dan اضْرِبْ. Fi'il madhi selalu berakhir fathah. Fi'il amr selalu majzum. Fi'il mudhari' diawali salah satu dari empat huruf tambahan yang dirangkum dalam أنيت, dan ia selalu marfu' sampai dimasuki amil nashab atau jazm.",
    explanation:
      "Mengenali bentuk fi'il membantu kita membaca waktu dan susunan kalimat. Fi'il mudhari' dapat berubah akhir katanya ketika didahului partikel tertentu, sehingga perlu diperhatikan apakah ia masih marfu', sudah manshub, atau menjadi majzum.",
    examples: [
      { arabic: "ضَرَبَ زَيْدٌ", translation: "Zaid telah memukul.", note: "ضَرَبَ adalah fi'il madhi." },
      { arabic: "يَضْرِبُ زَيْدٌ", translation: "Zaid sedang/akan memukul.", note: "يَضْرِبُ adalah fi'il mudhari' marfu'." },
      { arabic: "لَنْ يَضْرِبَ زَيْدٌ", translation: "Zaid tidak akan memukul.", note: "لَنْ menashabkan fi'il mudhari'." },
    ],
    irab: [
      { lafadz: "يَضْرِبُ", position: "فِعْلٌ مُضَارِعٌ مَرْفُوعٌ", sign: "ضَمَّةٌ", reason: "Tidak didahului amil nashab atau jazm." },
      { lafadz: "يَضْرِبَ", position: "فِعْلٌ مُضَارِعٌ مَنْصُوبٌ", sign: "فَتْحَةٌ", reason: "Didahului لَنْ sebagai amil nashab." },
    ],
    note: "Huruf mudhara'ah pada awal fi'il mudhari' dirangkum dengan kata أنيت: همزة، نون، ياء، تاء.",
    terms: ["fi'il", "madhi", "mudhari", "amr", "amil nashab", "amil jazm"],
  },
];

const chapterOutline: Array<[string, string, string, string[]]> = [
  ["marfuat", "مَرْفُوعَاتُ الأَسْمَاءِ", "Marfu'atul Asma", ["marfu'", "isim marfu'"]],
  ["fail", "الفَاعِلُ", "Fa'il", ["fa'il", "pelaku"]],
  ["naib-fail", "المَفْعُولُ الَّذِي لَمْ يُسَمَّ فَاعِلُهُ", "Naibul Fa'il", ["naibul fa'il", "pasif"]],
  ["mubtada-khabar", "المُبْتَدَأُ وَالخَبَرُ", "Mubtada dan Khabar", ["mubtada", "khabar"]],
  ["kana", "كَانَ وَأَخَوَاتُهَا", "Kana dan Saudaranya", ["kana", "amil nawasikh"]],
  ["inna", "إِنَّ وَأَخَوَاتُهَا", "Inna dan Saudaranya", ["inna", "amil nawasikh"]],
  ["dhanna", "ظَنَنْتُ وَأَخَوَاتُهَا", "Zhanantu dan Saudaranya", ["zhanna", "maf'ul"]],
  ["naat", "النَّعْتُ", "Na'at", ["naat", "sifat"]],
  ["athaf", "العَطْفُ", "'Athaf", ["athaf", "kata sambung"]],
  ["taukid", "التَّوْكِيدُ", "Taukid", ["taukid", "penguat"]],
  ["badal", "البَدَلُ", "Badal", ["badal", "pengganti"]],
  ["manshubat", "مَنْصُوبَاتُ الأَسْمَاءِ", "Manshubatul Asma", ["manshub", "isim manshub"]],
  ["maful-bih", "المَفْعُولُ بِهِ", "Maf'ul Bih", ["maf'ul bih", "objek"]],
  ["masdar", "المَصْدَرُ", "Mashdar", ["mashdar", "masdar"]],
  ["zharaf", "ظَرْفُ الزَّمَانِ وَظَرْفُ المَكَانِ", "Zharaf Waktu dan Tempat", ["zharaf", "keterangan"]],
  ["hal", "الحَالُ", "Hal", ["hal", "keadaan"]],
  ["tamyiz", "التَّمْيِيزُ", "Tamyiz", ["tamyiz", "pembeda"]],
  ["mustatsna", "المُسْتَثْنَى", "Istitsna", ["mustatsna", "pengecualian"]],
  ["la", "لَا", "Isim La", ["la", "isim la"]],
  ["munada", "المُنَادَى", "Munada", ["munada", "panggilan"]],
  ["maful-li-ajlih", "المَفْعُولُ لِأَجْلِهِ", "Maf'ul Li Ajlih", ["sebab", "maf'ul li ajlih"]],
  ["maful-maah", "المَفْعُولُ مَعَهُ", "Maf'ul Ma'ah", ["bersama", "maf'ul maah"]],
  ["makhfudhat", "مَخْفُوضَاتُ الأَسْمَاءِ", "Makhfudhatul Asma", ["majrur", "isim majrur"]],
  ["idhafah", "الإِضَافَةُ", "Idhafah", ["idhafah", "mudhaf"]],
  ["huruf-jar", "حُرُوفُ الجَرِّ", "Huruf Jar", ["huruf jar", "jar"]],
];

export const ALL_CHAPTERS: Chapter[] = [
  ...CHAPTERS,
  ...chapterOutline.map(([id, titleArabic, titleIndonesia, terms], index) => ({
    id,
    number: index + 5,
    titleArabic,
    titleIndonesia,
    summary: readySummary,
    status: "ready" as const,
    terms,
  })),
];

export const findChapter = (id: string | undefined) =>
  ALL_CHAPTERS.find((chapter) => chapter.id === id) ?? ALL_CHAPTERS[0];

export const searchChapters = (query: string) => {
  const normalized = query.trim().toLocaleLowerCase();
  if (!normalized) return ALL_CHAPTERS;
  return ALL_CHAPTERS.filter((chapter) =>
    [
      chapter.titleArabic,
      chapter.titleIndonesia,
      chapter.summary,
      chapter.matn ?? "",
      chapter.translation ?? "",
      chapter.explanation ?? "",
      ...(chapter.terms ?? []),
    ]
      .join(" ")
      .toLocaleLowerCase()
      .includes(normalized),
  );
};