import { BookOpenText, Menu, Moon, Search, Sun, X } from "lucide-react";
import { useState } from "react";
import type { ReactNode } from "react";
import { NavLink, Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { useLearning } from "@/lib/learning";

const navItems = [
  ["/", "Beranda", "nav-beranda"],
  ["/pengantar", "Kata Pengantar", "nav-pengantar"],
  ["/daftar-isi", "Daftar Isi", "nav-daftar-isi"],
  ["/baca/kalam", "Baca Kitab", "nav-baca-kitab"],
  ["/media", "Media", "nav-media"],
  ["/tentang", "Tentang", "nav-tentang"],
] as const;

export default function AppShell({ children }: { children: ReactNode }) {
  const { state, setTheme } = useLearning();
  const [menuOpen, setMenuOpen] = useState(false);

  return (
    <div data-testid="app-shell" className="min-h-screen bg-[var(--page-bg)] text-[var(--text-primary)]">
      <header data-testid="site-header" className="sticky top-0 z-50 border-b border-[var(--border)] bg-[var(--header-bg)]/95 shadow-[0_4px_24px_rgba(20,62,46,0.05)] backdrop-blur-xl">
        <div className="mx-auto flex h-[4.5rem] max-w-7xl items-center justify-between px-4 sm:px-6 lg:px-10">
          <Link to="/" data-testid="brand-link" className="group flex items-center gap-3" onClick={() => setMenuOpen(false)}>
            <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-[var(--emerald)] text-[var(--gold)] shadow-[0_6px_18px_rgba(20,62,46,0.2)] transition-transform duration-200 group-hover:-rotate-3">
              <BookOpenText size={21} strokeWidth={1.7} />
            </span>
            <span className="leading-none">
              <span data-testid="brand-name" className="block font-heading text-lg font-semibold tracking-tight text-[var(--emerald)] dark:text-[#f4efe6]">Jurumiyah Digital</span>
              <span data-testid="brand-caption" className="mt-1 block font-mono text-[9px] uppercase tracking-[0.22em] text-[var(--text-muted)]">Ruang belajar Nahwu</span>
            </span>
          </Link>

          <nav data-testid="desktop-navigation" className="hidden items-center gap-1 lg:flex">
            {navItems.map(([to, label, testId]) => (
              <NavLink
                key={to}
                to={to}
                data-testid={testId}
                className={({ isActive }) => `rounded-lg px-3 py-2 text-sm font-medium transition-colors duration-200 ${isActive ? "bg-[var(--gold-soft)] text-[var(--emerald)] dark:text-[var(--gold)]" : "text-[var(--text-secondary)] hover:bg-[var(--surface)] hover:text-[var(--emerald)]"}`}
                onClick={() => setMenuOpen(false)}
              >
                {label}
              </NavLink>
            ))}
          </nav>

          <div className="flex items-center gap-2">
            <Button
              variant="ghost"
              size="icon"
              data-testid="theme-toggle-button"
              aria-label={state.theme === "light" ? "Aktifkan mode gelap" : "Aktifkan mode terang"}
              onClick={() => setTheme(state.theme === "light" ? "dark" : "light")}
              className="text-[var(--text-secondary)] hover:bg-[var(--surface)] hover:text-[var(--emerald)]"
            >
              {state.theme === "light" ? <Moon size={18} /> : <Sun size={18} />}
            </Button>
            <Button
              variant="ghost"
              size="icon"
              data-testid="mobile-menu-button"
              aria-label={menuOpen ? "Tutup menu" : "Buka menu"}
              className="lg:hidden"
              onClick={() => setMenuOpen((open) => !open)}
            >
              {menuOpen ? <X size={20} /> : <Menu size={20} />}
            </Button>
          </div>
        </div>
        {menuOpen && (
          <nav data-testid="mobile-navigation" className="border-t border-[var(--border)] bg-[var(--page-bg)] px-4 py-3 lg:hidden">
            {navItems.map(([to, label, testId]) => (
              <NavLink key={to} to={to} data-testid={`${testId}-mobile`} className="flex items-center rounded-lg px-3 py-3 text-sm font-medium text-[var(--text-secondary)] hover:bg-[var(--surface)]" onClick={() => setMenuOpen(false)}>
                {label}
              </NavLink>
            ))}
            <Link to="/daftar-isi" data-testid="mobile-search-link" className="flex items-center gap-2 px-3 py-3 text-sm text-[var(--text-muted)]" onClick={() => setMenuOpen(false)}>
              <Search size={15} /> Cari materi
            </Link>
          </nav>
        )}
      </header>
      <main>{children}</main>
      <footer data-testid="site-footer" className="border-t border-[var(--border)] bg-[var(--surface-elevated)]">
        <div className="mx-auto flex max-w-7xl flex-col gap-2 px-4 py-8 text-sm text-[var(--text-muted)] sm:flex-row sm:items-center sm:justify-between sm:px-6 lg:px-10">
          <span data-testid="footer-copyright">Jurumiyah Digital · Media belajar ilmu Nahwu</span>
          <span data-testid="footer-source-note">Teks bab bertanda terverifikasi diambil dari sumber publik</span>
        </div>
      </footer>
    </div>
  );
}
