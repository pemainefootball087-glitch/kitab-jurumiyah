import { Check, Search, X } from "lucide-react";
import { Link, useLocation } from "react-router-dom";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { useLearning } from "@/lib/learning";
import { searchChapters } from "@/data/jurumiyah";
import { useState } from "react";

interface ChapterSidebarProps {
  open: boolean;
  onClose: () => void;
}

export default function ChapterSidebar({ open, onClose }: ChapterSidebarProps) {
  const location = useLocation();
  const { state } = useLearning();
  const [query, setQuery] = useState("");
  const chapters = searchChapters(query);

  return (
    <>
      {open && <button data-testid="sidebar-overlay" aria-label="Tutup daftar bab" className="fixed inset-0 z-30 bg-[#0d1714]/35 lg:hidden" onClick={onClose} />}
      <aside data-testid="chapter-sidebar" className={`fixed inset-y-0 left-0 z-40 mt-[4.5rem] w-[min(86vw,22rem)] overflow-y-auto border-r border-[var(--border)] bg-[var(--page-bg)] px-4 pb-8 pt-5 shadow-2xl transition-transform duration-300 lg:sticky lg:top-[4.5rem] lg:z-0 lg:mt-0 lg:block lg:h-[calc(100vh-4.5rem)] lg:w-[18rem] lg:shrink-0 lg:translate-x-0 lg:shadow-none ${open ? "translate-x-0" : "-translate-x-full"}`}>
        <div className="mb-5 flex items-center justify-between lg:hidden">
          <span data-testid="sidebar-mobile-title" className="font-heading font-semibold text-[var(--emerald)]">Daftar Bab</span>
          <button data-testid="sidebar-close-button" aria-label="Tutup sidebar" className="rounded-md p-2 text-[var(--text-muted)]" onClick={onClose}><X size={18} /></button>
        </div>
        <div className="mb-5">
          <label data-testid="sidebar-search-label" htmlFor="chapter-search" className="mb-2 block font-mono text-[10px] uppercase tracking-[0.18em] text-[var(--text-muted)]">Cari materi</label>
          <div className="relative">
            <Search size={15} className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-[var(--text-muted)]" />
            <Input id="chapter-search" data-testid="reader-search-input" value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Bab, istilah, contoh..." className="h-10 border-[var(--border)] bg-[var(--surface)] pl-9 text-sm focus-visible:ring-[var(--gold)]" />
          </div>
        </div>
        <div data-testid="chapter-list" className="space-y-1">
          {chapters.map((chapter) => {
            const active = location.pathname === `/baca/${chapter.id}`;
            const done = state.completed.includes(chapter.id);
            return (
              <Link key={chapter.id} to={`/baca/${chapter.id}`} data-testid={`chapter-list-item-${chapter.id}`} onClick={onClose} className={`group flex items-start gap-3 rounded-xl px-3 py-3 transition-colors duration-200 ${active ? "bg-[var(--emerald)] text-white shadow-[0_6px_16px_rgba(20,62,46,0.16)]" : "text-[var(--text-secondary)] hover:bg-[var(--surface)]"}`}>
                <span className={`mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center rounded-full font-mono text-[10px] ${active ? "bg-white/15 text-[var(--gold)]" : "bg-[var(--gold-soft)] text-[var(--emerald)]"}`}>{done ? <Check size={13} /> : String(chapter.number).padStart(2, "0")}</span>
                <span className="min-w-0">
                  <span dir="rtl" data-testid={`chapter-list-arabic-${chapter.id}`} className={`block font-arabic text-[15px] leading-6 ${active ? "text-white" : "text-[var(--text-primary)]"}`}>{chapter.titleArabic}</span>
                  <span data-testid={`chapter-list-indonesia-${chapter.id}`} className={`mt-0.5 block truncate text-xs ${active ? "text-white/70" : "text-[var(--text-muted)]"}`}>{chapter.titleIndonesia}</span>
                </span>
                {chapter.status === "verified" && <Badge data-testid={`chapter-verified-badge-${chapter.id}`} variant="outline" className={`ml-auto shrink-0 border-[var(--gold)] px-1.5 py-0 text-[9px] ${active ? "text-[var(--gold)]" : "text-[var(--gold-dark)]"}`}>✓</Badge>}
              </Link>
            );
          })}
          {chapters.length === 0 && <p data-testid="chapter-search-empty" className="rounded-lg bg-[var(--surface)] p-4 text-sm text-[var(--text-muted)]">Materi tidak ditemukan.</p>}
        </div>
      </aside>
    </>
  );
}
