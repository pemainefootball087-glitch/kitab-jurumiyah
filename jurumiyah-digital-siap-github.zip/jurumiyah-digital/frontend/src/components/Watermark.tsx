export default function Watermark() {
  return (
    <p data-testid="watermark-kang-alexx" className="mt-auto pt-12 text-center text-xs tracking-[0.18em] text-[var(--text-muted)]">
      Dibuat oleh Kang Alexx
    </p>
  );
}
