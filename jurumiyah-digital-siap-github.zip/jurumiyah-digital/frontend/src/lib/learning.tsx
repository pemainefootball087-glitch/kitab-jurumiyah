import { createContext, useContext, useEffect, useMemo, useState } from "react";
import type { ReactNode } from "react";

export type ThemeMode = "light" | "dark";

export interface LearningState {
  arabicFontSize: number;
  translationFontSize: number;
  theme: ThemeMode;
  bookmarks: string[];
  completed: string[];
  lastReadChapterId: string;
}

const STORAGE_KEY = "jurumiyah-digital-learning";

const DEFAULT_STATE: LearningState = {
  arabicFontSize: 30,
  translationFontSize: 17,
  theme: "light",
  bookmarks: [],
  completed: [],
  lastReadChapterId: "kalam",
};

function readState(): LearningState {
  if (typeof window === "undefined") return DEFAULT_STATE;
  try {
    const stored = window.localStorage.getItem(STORAGE_KEY);
    if (!stored) return DEFAULT_STATE;
    return { ...DEFAULT_STATE, ...JSON.parse(stored) } as LearningState;
  } catch {
    return DEFAULT_STATE;
  }
}

interface LearningContextValue {
  state: LearningState;
  setTheme: (theme: ThemeMode) => void;
  setArabicFontSize: (size: number) => void;
  setTranslationFontSize: (size: number) => void;
  setLastReadChapter: (id: string) => void;
  toggleBookmark: (id: string) => void;
  toggleCompleted: (id: string) => void;
}

const LearningContext = createContext<LearningContextValue | null>(null);

export function LearningProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<LearningState>(readState);

  useEffect(() => {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    document.documentElement.classList.toggle("dark", state.theme === "dark");
  }, [state]);

  const value = useMemo<LearningContextValue>(
    () => ({
      state,
      setTheme: (theme) => setState((current) => ({ ...current, theme })),
      setArabicFontSize: (arabicFontSize) =>
        setState((current) => ({ ...current, arabicFontSize })),
      setTranslationFontSize: (translationFontSize) =>
        setState((current) => ({ ...current, translationFontSize })),
      setLastReadChapter: (lastReadChapterId) =>
        setState((current) => ({ ...current, lastReadChapterId })),
      toggleBookmark: (id) =>
        setState((current) => ({
          ...current,
          bookmarks: current.bookmarks.includes(id)
            ? current.bookmarks.filter((item) => item !== id)
            : [...current.bookmarks, id],
        })),
      toggleCompleted: (id) =>
        setState((current) => ({
          ...current,
          completed: current.completed.includes(id)
            ? current.completed.filter((item) => item !== id)
            : [...current.completed, id],
        })),
    }),
    [state],
  );

  return <LearningContext.Provider value={value}>{children}</LearningContext.Provider>;
}

export function useLearning() {
  const context = useContext(LearningContext);
  if (!context) throw new Error("useLearning harus digunakan di dalam LearningProvider");
  return context;
}
