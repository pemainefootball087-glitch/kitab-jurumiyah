import { Routes, Route } from "react-router-dom";
import AppShell from "@/components/AppShell";
import { LearningProvider } from "@/lib/learning";
import Home from "@/pages/Home";
import Preface from "@/pages/Preface";
import Contents from "@/pages/Contents";
import Reader from "@/pages/Reader";
import About from "@/pages/About";
import Media from "@/pages/Media";
import AdminMedia from "@/pages/AdminMedia";

// One <Route> per page in src/pages; BrowserRouter already wraps this in main.tsx.
export default function App() {
  return (
    <LearningProvider>
      <AppShell>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/pengantar" element={<Preface />} />
          <Route path="/daftar-isi" element={<Contents />} />
          <Route path="/baca/:chapterId" element={<Reader />} />
          <Route path="/media" element={<Media />} />
          <Route path="/admin/media" element={<AdminMedia />} />
          <Route path="/tentang" element={<About />} />
        </Routes>
      </AppShell>
    </LearningProvider>
  );
}
