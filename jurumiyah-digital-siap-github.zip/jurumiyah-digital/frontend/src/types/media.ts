export interface MediaAsset {
  id: string;
  original_filename: string;
  content_type: string;
  size: number;
  category: "source" | "kitab" | "image" | "audio" | "asset";
  description: string;
  created_at: string;
}

export interface MediaUploadResponse {
  asset: MediaAsset;
  message: string;
}

export interface MediaDeleteResponse {
  id: string;
  deleted: boolean;
  message: string;
}

export interface StorageStatus {
  configured: boolean;
  allowed_extensions: string[];
  max_size_mb: number;
}
