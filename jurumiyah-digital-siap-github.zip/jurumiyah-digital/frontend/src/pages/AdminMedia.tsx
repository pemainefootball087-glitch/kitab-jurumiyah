import { FileUp, LockKeyhole, ShieldCheck, Trash2, UploadCloud } from "lucide-react";
import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { apiAdminDelete, apiGet, apiUpload } from "@/lib/api";
import type { MediaAsset, MediaDeleteResponse, MediaUploadResponse, StorageStatus } from "@/types/media";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Toaster } from "@/components/ui/sonner";

const CATEGORY_LABELS: Record<string, string> = { source: "Source code", kitab: "Kitab / PDF", image: "Gambar", audio: "Audio", asset: "Aset lain" };

export default function AdminMedia() {
  const queryClient = useQueryClient();
  const [pin, setPin] = useState("");
  const [file, setFile] = useState<File | null>(null);
  const [category, setCategory] = useState("source");
  const [description, setDescription] = useState("");
  const mediaQuery = useQuery({ queryKey: ["media"], queryFn: () => apiGet<MediaAsset[]>("/media"), retry: false });
  const statusQuery = useQuery({ queryKey: ["media-status"], queryFn: () => apiGet<StorageStatus>("/media/status"), retry: false });

  const uploadMutation = useMutation({
    mutationFn: async () => {
      if (!file) throw new Error("Pilih file terlebih dahulu");
      const data = new FormData();
      data.append("file", file);
      data.append("category", category);
      data.append("description", description);
      return apiUpload<MediaUploadResponse>("/media/upload", data, pin);
    },
    onSuccess: async () => {
      await queryClient.invalidateQueries({ queryKey: ["media"] });
      setFile(null);
      setDescription("");
      const input = document.querySelector<HTMLInputElement>('[data-testid="admin-file-input"]');
      if (input) input.value = "";
      toast.success("File berhasil diterbitkan");
    },
    onError: () => toast.error("Upload gagal. Periksa PIN, jenis, dan ukuran file."),
  });

  const deleteMutation = useMutation({
    mutationFn: (id: string) => apiAdminDelete<MediaDeleteResponse>(`/media/${id}`, pin),
    onSuccess: async () => {
      await queryClient.invalidateQueries({ queryKey: ["media"] });
      toast.success("File dihapus dari pustaka publik");
    },
    onError: () => toast.error("Penghapusan gagal. Periksa PIN admin."),
  });

  return (
    <div data-testid="admin-media-page" className="page-wrap">
      <Toaster richColors />
      <div className="mx-auto max-w-5xl px-4 py-12 sm:px-6 lg:py-20">
        <div className="mb-8"><p data-testid="admin-media-kicker" className="eyebrow">Area terbatas</p><h1 data-testid="admin-media-title" className="mt-3 font-heading text-4xl font-semibold text-[var(--emerald)] dark:text-[#f4efe6]">Kelola File & Media</h1><p data-testid="admin-media-description" className="mt-4 max-w-2xl text-sm leading-7 text-[var(--text-secondary)]">Unggah source ZIP, PDF, gambar, atau audio. PIN hanya digunakan pada request admin dan tidak disimpan di browser.</p></div>
        <div data-testid="admin-storage-status" className="mb-6 flex items-center gap-2 rounded-xl border border-[var(--border)] bg-[var(--surface-elevated)] px-4 py-3 text-sm text-[var(--text-secondary)]"><ShieldCheck size={17} className="text-[var(--gold-dark)]" />{statusQuery.data?.configured ? `Storage aktif · maksimal ${statusQuery.data.max_size_mb} MB` : "Storage belum dikonfigurasi"}</div>
        <form data-testid="admin-upload-form" className="paper-panel grid gap-5 p-6 sm:p-8" onSubmit={(event) => { event.preventDefault(); uploadMutation.mutate(); }}>
          <div><Label htmlFor="admin-pin" data-testid="admin-pin-label">PIN Admin</Label><div className="relative mt-2"><LockKeyhole size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-[var(--text-muted)]" /><Input id="admin-pin" data-testid="admin-pin-input" type="password" value={pin} onChange={(event) => setPin(event.target.value)} placeholder="Masukkan PIN admin" className="pl-9" required /></div></div>
          <div className="grid gap-5 sm:grid-cols-2"><div><Label htmlFor="admin-file" data-testid="admin-file-label">Pilih file</Label><Input id="admin-file" data-testid="admin-file-input" type="file" accept=".zip,.pdf,.png,.jpg,.jpeg,.webp,.mp3,.wav,.json,.md" className="mt-2" onChange={(event) => setFile(event.target.files?.[0] ?? null)} required /></div><div><Label data-testid="admin-category-label">Kategori</Label><Select value={category} onValueChange={setCategory}><SelectTrigger data-testid="admin-category-select" className="mt-2 w-full"><SelectValue>{(value) => CATEGORY_LABELS[value as string]}</SelectValue></SelectTrigger><SelectContent>{Object.entries(CATEGORY_LABELS).map(([value, label]) => <SelectItem key={value} value={value} data-testid={`admin-category-${value}`}>{label}</SelectItem>)}</SelectContent></Select></div></div>
          <div><Label htmlFor="admin-description" data-testid="admin-description-label">Deskripsi</Label><Textarea id="admin-description" data-testid="admin-description-input" value={description} onChange={(event) => setDescription(event.target.value)} placeholder="Jelaskan isi file agar mudah dikenali pengunjung" maxLength={300} className="mt-2 min-h-24" /></div>
          <Button data-testid="admin-upload-button" type="submit" disabled={uploadMutation.isPending || !file || !pin} className="w-fit bg-[var(--emerald)] text-white hover:bg-[var(--emerald-hover)]"><UploadCloud size={17} />{uploadMutation.isPending ? "Mengunggah…" : "Unggah dan Terbitkan"}</Button>
        </form>
        <section data-testid="admin-media-list" className="mt-10"><div className="flex items-center gap-2"><FileUp size={18} className="text-[var(--gold-dark)]" /><h2 data-testid="admin-list-title" className="font-heading text-2xl font-semibold text-[var(--emerald)] dark:text-[#f4efe6]">File diterbitkan</h2></div><div className="mt-5 space-y-3">{(mediaQuery.data ?? []).map((asset) => <div key={asset.id} data-testid={`admin-media-item-${asset.id}`} className="flex items-center gap-4 rounded-xl border border-[var(--border)] bg-[var(--surface)] p-4"><div className="min-w-0 flex-1"><p className="truncate text-sm font-medium">{asset.original_filename}</p><p className="mt-1 text-xs text-[var(--text-muted)]">{CATEGORY_LABELS[asset.category] ?? asset.category}</p></div><Button data-testid={`admin-delete-${asset.id}`} variant="ghost" size="icon" aria-label={`Hapus ${asset.original_filename}`} disabled={!pin || deleteMutation.isPending} onClick={() => deleteMutation.mutate(asset.id)} className="text-red-600 hover:bg-red-50 hover:text-red-700"><Trash2 size={16} /></Button></div>)}{!mediaQuery.isLoading && (mediaQuery.data ?? []).length === 0 && <p data-testid="admin-list-empty" className="rounded-xl border border-dashed border-[var(--border)] p-6 text-sm text-[var(--text-muted)]">Belum ada file di pustaka media.</p>}</div></section>
      </div>
    </div>
  );
}
