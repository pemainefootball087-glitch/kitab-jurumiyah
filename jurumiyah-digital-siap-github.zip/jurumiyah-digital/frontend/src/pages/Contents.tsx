import { ArrowUpRight, BookMarked, Search, ShieldCheck } from "lucide-react";
import { useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { ALL_CHAPTERS, searchChapters } from "@/data/jurumiyah";

export default function Contents() {
  const [query, setQuery] = useState("");
  const chapters = useMemo(() => searchChapters(query), [query]);
  return (
    <div data-testid="contents-page" className="page-wrap">
      <div className="mx-auto max-w-6xl px-4 py-12 sm:px-6 lg:py-20">
        <div className="flex flex-col justify-between gap-8 border-b border-[var(--border)] pb-10 sm:flex-row sm:items-end">
          <div><p data-testid="contents-kicker" className="eyebrow">Jelajahi pembahasan</p><h1 data-testid="contents-title" className="mt-3 font-heading text-4xl font-semibold tracking-tight text-[var(--emerald)] dark:text-[#f4efe6] sm:text-5xl">Daftar Isi</h1><p data-testid="contents-description" className="mt-4 max-w-xl text-base leading-7 text-[var(--text-secondary)]">29 pembahasan disusun berurutan agar perjalanan belajar dari dasar sampai kaidah-kaidah penting terasa terarah.</p></div>
          <div className="flex items-center gap-2 text-sm text-[var(--text-muted)]"><BookMarked size={17} className="text-[var(--gold-dark)]" /><span data-testid="contents-count">{ALL_CHAPTERS.length} bab terstruktur</span></div>
        </div>
        <div className="mt-8 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div className="relative max-w-md flex-1"><Search size={16} className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-[var(--text-muted)]" /><Input data-testid="contents-search-input" value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Cari judul bab atau istilah Nahwu..." className="h-11 border-[var(--border)] bg-[var(--surface)] pl-9 focus-visible:ring-[var(--gold)]" /></div>
          <div data-testid="contents-legend" className="flex items-center gap-4 text-xs text-[var(--text-muted)]"><span className="flex items-center gap-1.5"><ShieldCheck size={14} className="text-[var(--gold-dark)]" /> teks terverifikasi</span><span>○ siap diisi</span></div>
        </div>
        <div data-testid="contents-list" className="mt-8 grid gap-3 md:grid-cols-2">
          {chapters.map((chapter) => (
            <Link key={chapter.id} to={`/baca/${chapter.id}`} data-testid={`contents-item-${chapter.id}`} className="group flex min-h-[108px] items-start gap-4 rounded-2xl border border-[var(--border)] bg-[var(--surface)] p-5 shadow-[0_4px_15px_rgba(20,62,46,0.03)] transition-[transform,box-shadow,border-color] duration-200 hover:-translate-y-0.5 hover:border-[var(--gold)] hover:shadow-[0_10px_28px_rgba(20,62,46,0.08)]">
              <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-[var(--gold-soft)] font-mono text-xs font-semibold text-[var(--emerald)]">{String(chapter.number).padStart(2, "0")}</span>
              <span className="min-w-0 flex-1"><span dir="rtl" data-testid={`contents-arabic-${chapter.id}`} className="block font-arabic text-xl leading-8 text-[var(--arabic-text)]">{chapter.titleArabic}</span><span data-testid={`contents-indonesia-${chapter.id}`} className="mt-1 block text-sm font-medium text-[var(--text-primary)]">{chapter.titleIndonesia}</span><span data-testid={`contents-summary-${chapter.id}`} className="mt-2 block line-clamp-2 text-xs leading-5 text-[var(--text-muted)]">{chapter.status === "verified" ? chapter.summary : "Struktur bab siap dikembangkan tanpa teks palsu."}</span></span>
              <span className="flex shrink-0 flex-col items-end gap-2"><ArrowUpRight size={17} className="text-[var(--text-muted)] transition-transform duration-200 group-hover:-translate-y-0.5 group-hover:translate-x-0.5 group-hover:text-[var(--gold-dark)]" />{chapter.status === "verified" ? <Badge data-testid={`contents-verified-${chapter.id}`} variant="outline" className="border-[var(--gold)] px-1.5 text-[9px] text-[var(--gold-dark)]">valid</Badge> : <span data-testid={`contents-ready-${chapter.id}`} className="text-[9px] font-mono uppercase tracking-wider text-[var(--text-muted)]">siap isi</span>}</span>
            </Link>
          ))}
        </div>
        {chapters.length === 0 && <p data-testid="contents-empty" className="mt-8 rounded-2xl border border-dashed border-[var(--border)] p-8 text-center text-sm text-[var(--text-muted)]">Belum ada bab yang cocok dengan pencarian.</p>}
      </div>
    </div>
  );
}
