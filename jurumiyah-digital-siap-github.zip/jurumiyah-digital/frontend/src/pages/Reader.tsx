import { ArrowLeft, ArrowRight, Bookmark, Check, ChevronLeft, ChevronRight, Menu, Settings2 } from "lucide-react";
import { useEffect, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ALL_CHAPTERS, findChapter } from "@/data/jurumiyah";
import ChapterSidebar from "@/components/ChapterSidebar";
import { useLearning } from "@/lib/learning";

export default function Reader() {
  const { chapterId } = useParams();
  const navigate = useNavigate();
  const rawChapter = findChapter(chapterId);
  const chapter = { ...rawChapter, matn: rawChapter.matn?.replace("المُر\uFFFD\uFFFDك", "المُرَك").replace("السَّالِ\uFFFD\uFFFDِ", "السَّالِمِ") };
  const { state, setArabicFontSize, setTranslationFontSize, setLastReadChapter, toggleBookmark, toggleCompleted } = useLearning();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const currentIndex = ALL_CHAPTERS.findIndex((item) => item.id === chapter.id);
  const previous = ALL_CHAPTERS[currentIndex - 1];
  const next = ALL_CHAPTERS[currentIndex + 1];
  const bookmarked = state.bookmarks.includes(chapter.id);
  const completed = state.completed.includes(chapter.id);

  useEffect(() => {
    if (!chapterId || !ALL_CHAPTERS.some((item) => item.id === chapterId)) navigate("/baca/kalam", { replace: true });
    else setLastReadChapter(chapterId);
  }, [chapterId, navigate]);

  const goTo = (id: string) => {
    setSidebarOpen(false);
    window.scrollTo({ top: 0, behavior: "smooth" });
    navigate(`/baca/${id}`);
  };

  return (
    <div data-testid="reader-page" className="min-h-[calc(100vh-4.5rem)] bg-[var(--page-bg)]">
      <div className="flex max-w-[1600px] mx-auto">
        <ChapterSidebar open={sidebarOpen} onClose={() => setSidebarOpen(false)} />
        <section className="min-w-0 flex-1">
          <div className="mx-auto max-w-4xl px-4 py-6 sm:px-6 lg:px-12 lg:py-10">
            <div data-testid="reader-toolbar" className="mb-8 flex flex-wrap items-center justify-between gap-3">
              <Button variant="outline" size="sm" data-testid="open-sidebar-button" className="border-[var(--border)] bg-[var(--surface)] text-[var(--text-secondary)] lg:hidden" onClick={() => setSidebarOpen(true)}><Menu size={16} /> Daftar bab</Button>
              <div className="flex items-center gap-2"><Badge data-testid="reader-chapter-number" variant="outline" className="border-[var(--gold)] text-[var(--gold-dark)]">Bab {String(chapter.number).padStart(2, "0")}</Badge><span data-testid="reader-progress-label" className="text-xs text-[var(--text-muted)]">{state.completed.length}/{ALL_CHAPTERS.length} selesai</span></div>
              <Button variant="ghost" size="sm" data-testid="reader-settings-button" className="ml-auto text-[var(--text-secondary)]" onClick={() => setSettingsOpen((open) => !open)}><Settings2 size={16} /> Pengaturan</Button>
            </div>
            {settingsOpen && <div data-testid="reader-settings-panel" className="mb-8 grid gap-5 rounded-2xl border border-[var(--border)] bg-[var(--surface)] p-5 sm:grid-cols-2"><label data-testid="arabic-font-setting" className="text-sm text-[var(--text-secondary)]">Ukuran teks Arab <span className="float-right font-mono text-xs text-[var(--gold-dark)]">{state.arabicFontSize}px</span><input data-testid="font-arabic-slider" type="range" min="24" max="42" value={state.arabicFontSize} onChange={(event) => setArabicFontSize(Number(event.target.value))} className="mt-3 w-full accent-[var(--gold-dark)]" /></label><label data-testid="translation-font-setting" className="text-sm text-[var(--text-secondary)]">Ukuran terjemahan <span className="float-right font-mono text-xs text-[var(--gold-dark)]">{state.translationFontSize}px</span><input data-testid="font-translation-slider" type="range" min="15" max="24" value={state.translationFontSize} onChange={(event) => setTranslationFontSize(Number(event.target.value))} className="mt-3 w-full accent-[var(--gold-dark)]" /></label></div>}

            <header data-testid="reader-header" className="border-b border-[var(--border)] pb-9">
              <div className="flex items-start justify-between gap-5"><div><p data-testid="reader-kicker" className="eyebrow">Pembahasan {String(chapter.number).padStart(2, "0")}</p><h1 data-testid="reader-title-indonesia" className="mt-3 font-heading text-3xl font-semibold tracking-tight text-[var(--emerald)] dark:text-[#f4efe6] sm:text-5xl">{chapter.titleIndonesia}</h1><h2 dir="rtl" data-testid="reader-title-arabic" className="mt-3 font-arabic text-2xl leading-loose text-[var(--arabic-text)] sm:text-3xl">{chapter.titleArabic}</h2></div><button data-testid="bookmark-button" aria-label={bookmarked ? "Hapus bookmark" : "Simpan bookmark"} className={`mt-1 rounded-xl border p-3 transition-[background-color,color,border-color,transform] duration-200 hover:-translate-y-0.5 ${bookmarked ? "border-[var(--gold)] bg-[var(--gold-soft)] text-[var(--gold-dark)]" : "border-[var(--border)] text-[var(--text-muted)] hover:border-[var(--gold)] hover:text-[var(--gold-dark)]"}`} onClick={() => toggleBookmark(chapter.id)}><Bookmark size={19} fill={bookmarked ? "currentColor" : "none"} /></button></div><p data-testid="reader-summary" className="mt-5 max-w-2xl text-base leading-7 text-[var(--text-secondary)]">{chapter.summary}</p><div className="mt-5 flex items-center gap-2 text-xs text-[var(--text-muted)]">{chapter.status === "verified" ? <><Check size={14} className="text-[var(--gold-dark)]" /><span data-testid="verified-source-label">Teks inti terverifikasi dari sumber publik</span></> : <><span data-testid="ready-source-label" className="h-1.5 w-1.5 rounded-full bg-[var(--gold-dark)]" /><span>Struktur tersedia · teks sumber belum dimasukkan</span></>}</div>
            </header>

            {chapter.status === "verified" ? <article data-testid="lesson-content" className="space-y-10 py-10">
              <section data-testid="matn-section" className="lesson-section matn-section"><div className="section-label"><span className="section-number">01</span><span>Teks Kitab</span></div><p dir="rtl" data-testid="matn-arabic-text" style={{ fontSize: `${state.arabicFontSize}px` }} className="mt-5 font-arabic leading-[2.35] tracking-wide text-[var(--arabic-text)]">{chapter.matn}</p></section>
              <section data-testid="translation-section" className="lesson-section"><div className="section-label"><span className="section-number">02</span><span>Terjemahan</span></div><p data-testid="translation-text" style={{ fontSize: `${state.translationFontSize}px` }} className="mt-5 leading-8 text-[var(--text-secondary)]">{chapter.translation}</p></section>
              <section data-testid="explanation-section" className="lesson-section"><div className="section-label"><span className="section-number">03</span><span>Penjelasan</span></div><p data-testid="explanation-text" className="mt-5 text-base leading-8 text-[var(--text-secondary)]">{chapter.explanation}</p></section>
              <section data-testid="examples-section" className="lesson-section"><div className="section-label"><span className="section-number">04</span><span>Contoh</span></div><div className="mt-5 grid gap-3">{chapter.examples?.map((example, index) => <div key={example.arabic} data-testid={`example-card-${index + 1}`} className="rounded-xl border border-[var(--border)] bg-[var(--surface)] p-5"><p dir="rtl" className="font-arabic text-xl leading-loose text-[var(--arabic-text)] sm:text-2xl">{example.arabic}</p><p className="mt-2 text-sm text-[var(--text-primary)]">{example.translation}</p>{example.note && <p className="mt-2 text-xs leading-5 text-[var(--text-muted)]">{example.note}</p>}</div>)}</div></section>
              <section data-testid="irab-section" className="lesson-section"><div className="section-label"><span className="section-number">05</span><span>Contoh I'rab</span></div><div className="mt-5 overflow-x-auto rounded-xl border border-[var(--border)]"><table data-testid="irab-table" className="w-full min-w-[620px] text-left text-sm"><thead className="bg-[var(--surface-elevated)] text-xs uppercase tracking-wider text-[var(--text-muted)]"><tr><th className="px-4 py-3">Lafadz</th><th className="px-4 py-3">Kedudukan</th><th className="px-4 py-3">Tanda</th><th className="px-4 py-3">Alasan</th></tr></thead><tbody className="divide-y divide-[var(--border)]">{chapter.irab?.map((row) => <tr key={row.lafadz} data-testid={`irab-row-${row.lafadz}`}><td dir="rtl" className="px-4 py-4 font-arabic text-lg text-[var(--arabic-text)]">{row.lafadz}</td><td className="px-4 py-4 text-[var(--text-primary)]">{row.position}</td><td className="px-4 py-4 text-[var(--gold-dark)]">{row.sign}</td><td className="px-4 py-4 text-[var(--text-secondary)]">{row.reason}</td></tr>)}</tbody></table></div></section>
              <section data-testid="note-section" className="rounded-2xl border border-[var(--gold)]/35 bg-[var(--gold-soft)] p-6"><div className="section-label text-[var(--gold-dark)]"><span className="section-number">06</span><span>Catatan penting</span></div><p data-testid="important-note" className="mt-4 text-sm leading-7 text-[var(--text-primary)]">{chapter.note}</p></section>
            </article> : <div data-testid="lesson-ready-state" className="my-10 rounded-2xl border border-dashed border-[var(--gold)] bg-[var(--surface)] p-8 text-center sm:p-14"><span className="mx-auto flex h-12 w-12 items-center justify-center rounded-full bg-[var(--gold-soft)] text-[var(--gold-dark)]"><BookOpenIcon /></span><h2 data-testid="ready-state-title" className="mt-5 font-heading text-2xl font-semibold text-[var(--emerald)] dark:text-[#f4efe6]">Ruang bab ini sudah siap</h2><p data-testid="ready-state-copy" className="mx-auto mt-3 max-w-lg text-sm leading-7 text-[var(--text-secondary)]">Teks Arab asli, terjemahan, penjelasan, contoh, dan i'rab untuk bab ini belum dimasukkan. Tidak ada teks rekaan yang ditampilkan sebagai matan. Tambahkan data pada <code className="rounded bg-[var(--surface-elevated)] px-1.5 py-0.5 text-xs">src/data/jurumiyah.ts</code> saat sumber sudah disunting.</p><Badge data-testid="ready-state-badge" variant="outline" className="mt-5 border-[var(--gold)] text-[var(--gold-dark)]">Menunggu sumber terverifikasi</Badge></div>}

            <div data-testid="reader-completion-actions" className="flex flex-col gap-3 border-t border-[var(--border)] py-8 sm:flex-row sm:items-center sm:justify-between"><Button data-testid="complete-chapter-button" variant={completed ? "secondary" : "default"} className={completed ? "bg-[var(--gold-soft)] text-[var(--gold-dark)]" : "bg-[var(--emerald)] text-white hover:bg-[var(--emerald-hover)]"} onClick={() => toggleCompleted(chapter.id)}><Check size={16} />{completed ? "Bab ditandai selesai" : "Tandai bab selesai"}</Button><span data-testid="reader-bookmark-status" className="text-sm text-[var(--text-muted)]">{bookmarked ? "Bab ini tersimpan di bookmark" : "Simpan bab untuk dibaca lagi"}</span></div>
            <div data-testid="chapter-navigation" className="grid gap-3 border-t border-[var(--border)] pt-6 sm:grid-cols-2">{previous ? <button data-testid="chapter-previous-button" className="group rounded-xl border border-[var(--border)] bg-[var(--surface)] p-4 text-left transition-[border-color,transform] duration-200 hover:-translate-y-0.5 hover:border-[var(--gold)]" onClick={() => goTo(previous.id)}><span className="flex items-center gap-2 text-xs text-[var(--text-muted)]"><ChevronLeft size={15} /> Bab sebelumnya</span><span className="mt-2 block font-heading font-semibold text-[var(--emerald)] dark:text-[#f4efe6]">{previous.titleIndonesia}</span></button> : <span />}{next && <button data-testid="chapter-next-button" className="group rounded-xl border border-[var(--border)] bg-[var(--surface)] p-4 text-right transition-[border-color,transform] duration-200 hover:-translate-y-0.5 hover:border-[var(--gold)]" onClick={() => goTo(next.id)}><span className="flex items-center justify-end gap-2 text-xs text-[var(--text-muted)]">Bab berikutnya <ChevronRight size={15} /></span><span className="mt-2 block font-heading font-semibold text-[var(--emerald)] dark:text-[#f4efe6]">{next.titleIndonesia}</span></button>}</div>
          </div>
        </section>
      </div>
    </div>
  );
}

function BookOpenIcon() {
  return <span className="font-arabic text-xl">ك</span>;
}
