import { ArrowRight, BookOpenText, ChevronRight } from "lucide-react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import Watermark from "@/components/Watermark";

export default function Preface() {
  return (
    <div data-testid="preface-page" className="page-wrap">
      <div className="mx-auto max-w-4xl px-4 py-12 sm:px-6 lg:py-20">
        <div data-testid="preface-breadcrumb" className="mb-8 flex items-center gap-2 font-mono text-[10px] uppercase tracking-[0.18em] text-[var(--text-muted)]"><Link to="/" data-testid="preface-home-link" className="hover:text-[var(--gold-dark)]">Beranda</Link><ChevronRight size={13} /><span>Kata Pengantar</span></div>
        <div className="paper-panel relative overflow-hidden p-6 sm:p-10 lg:p-14">
          <div className="absolute right-7 top-7 text-[var(--gold)] opacity-40"><BookOpenText size={25} strokeWidth={1.4} /></div>
          <p data-testid="preface-kicker" className="eyebrow">Sebelum membaca</p>
          <h1 data-testid="preface-title" className="mt-3 font-heading text-3xl font-semibold tracking-tight text-[var(--emerald)] dark:text-[#f4efe6] sm:text-4xl">Kata Pengantar</h1>
          <div data-testid="preface-content" className="mt-10 space-y-6 text-base leading-8 text-[var(--text-secondary)] sm:text-[17px]">
            <p dir="rtl" data-testid="preface-basmala" className="font-arabic text-center text-3xl leading-loose text-[var(--arabic-text)]">بِسْمِ اللهِ الرَّحْمٰنِ الرَّحِيْمِ</p>
            <p>Alhamdulillah, segala puji bagi Allah SWT yang telah memberikan rahmat dan kemudahan kepada kita semua. Shalawat serta salam semoga selalu tercurah kepada Nabi Muhammad SAW, keluarga, sahabat, dan seluruh umatnya.</p>
            <p>Kitab Al-Jurumiyah merupakan salah satu kitab dasar yang banyak dipelajari dalam ilmu Nahwu. Dengan mempelajari ilmu Nahwu, kita dapat memahami susunan bahasa Arab dengan lebih baik, terutama dalam membaca dan memahami kitab-kitab berbahasa Arab.</p>
            <p>Website ini dibuat sebagai media untuk membantu pembaca mempelajari Kitab Al-Jurumiyah dengan lebih mudah. Di dalamnya terdapat teks kitab, terjemahan, penjelasan, serta contoh-contoh yang diharapkan dapat membantu dalam memahami setiap pembahasan.</p>
            <p>Semoga website ini dapat memberikan manfaat bagi para santri, pelajar, dan siapa saja yang ingin belajar ilmu Nahwu. Semoga Allah SWT memberikan kemudahan kepada kita dalam menuntut ilmu dan menjadikan ilmu yang kita pelajari sebagai ilmu yang bermanfaat.</p>
            <p>Selamat belajar dan semoga bermanfaat.</p>
            <p dir="rtl" data-testid="preface-closing" className="font-arabic text-center text-2xl leading-loose text-[var(--arabic-text)]">وَاللهُ أَعْلَمُ بِالصَّوَابِ</p>
          </div>
          <div className="mt-10 flex flex-col gap-3 border-t border-[var(--border)] pt-7 sm:flex-row">
            <Button data-testid="preface-contents-button" className="bg-[var(--emerald)] text-white hover:bg-[var(--emerald-hover)]"><Link to="/daftar-isi">Lihat Daftar Isi <ArrowRight size={16} /></Link></Button>
            <Button variant="outline" data-testid="preface-reading-button" className="border-[var(--border)] text-[var(--emerald)] hover:bg-[var(--gold-soft)]"><Link to="/baca/kalam">Mulai membaca</Link></Button>
          </div>
          <Watermark />
        </div>
      </div>
    </div>
  );
}
