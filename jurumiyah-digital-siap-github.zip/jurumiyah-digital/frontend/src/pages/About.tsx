import { Archive, Download, ExternalLink, Heart, Target } from "lucide-react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import Watermark from "@/components/Watermark";
import { SOURCE_URL } from "@/data/jurumiyah";

const points = [
  [Archive, "Apa itu Al-Jurumiyah?", "Al-Jurumiyah adalah matan ringkas yang menjadi salah satu pintu masuk populer untuk mempelajari dasar-dasar ilmu Nahwu."],
  [Target, "Tujuan website", "Menyediakan ruang baca digital yang tertata, nyaman di layar kecil maupun besar, dan mudah dikembangkan bersama data kitab yang terpisah."],
  [Heart, "Untuk siapa?", "Santri, pelajar, pengajar, dan siapa saja yang ingin memahami susunan bahasa Arab secara bertahap."],
] as const;

export default function About() {
  return (
    <div data-testid="about-page" className="page-wrap">
      <div className="mx-auto max-w-5xl px-4 py-12 sm:px-6 lg:py-20">
        <div className="mb-10 max-w-3xl"><p data-testid="about-kicker" className="eyebrow">Tentang ruang belajar</p><h1 data-testid="about-title" className="mt-3 font-heading text-4xl font-semibold tracking-tight text-[var(--emerald)] dark:text-[#f4efe6] sm:text-5xl">Belajar Nahwu, satu bab demi satu bab.</h1><p data-testid="about-lead" className="mt-5 text-lg leading-8 text-[var(--text-secondary)]">Jurumiyah Digital dirancang sebagai media pembelajaran, bukan sekadar halaman informasi. Setiap fitur dibuat untuk membantu pembaca membaca, menandai, dan kembali ke pelajaran terakhirnya.</p></div>
        <div data-testid="about-points" className="grid gap-4 md:grid-cols-3">{points.map(([Icon, title, text]) => <article key={title} data-testid={`about-point-${title}`} className="paper-panel p-6"><span className="flex h-10 w-10 items-center justify-center rounded-xl bg-[var(--gold-soft)] text-[var(--gold-dark)]"><Icon size={19} /></span><h2 className="mt-5 font-heading text-xl font-semibold text-[var(--emerald)] dark:text-[#f4efe6]">{title}</h2><p className="mt-3 text-sm leading-6 text-[var(--text-secondary)]">{text}</p></article>)}</div>
        <section data-testid="about-learning-benefit" className="mt-6 rounded-2xl bg-[var(--emerald)] p-7 text-white sm:p-10"><p className="eyebrow text-[var(--gold)]">Cara kerja</p><h2 data-testid="about-benefit-title" className="mt-3 font-heading text-2xl font-semibold">Membaca dengan ritme yang Anda pilih</h2><p data-testid="about-benefit-text" className="mt-3 max-w-2xl text-sm leading-7 text-white/75">Progress, bookmark, bab terakhir, tema, dan ukuran huruf disimpan di perangkat Anda melalui localStorage. Tidak perlu login dan tidak ada data belajar yang dikirim ke layanan pihak ketiga.</p><div className="mt-6 flex flex-wrap gap-3"><Button data-testid="about-read-button" className="bg-[var(--gold)] text-[#1a2421] hover:bg-[#e5c158]"><Link to="/baca/kalam">Mulai membaca</Link></Button><a href={SOURCE_URL} target="_blank" rel="noreferrer" data-testid="about-source-link" className="inline-flex h-9 items-center gap-2 rounded-md border border-white/25 px-4 text-sm text-white transition-colors hover:bg-white/10">Lihat sumber <ExternalLink size={15} /></a></div></section>
        <div data-testid="about-project-export" className="mt-6 flex flex-col gap-4 rounded-2xl border border-dashed border-[var(--border)] bg-[var(--surface-elevated)] p-6 sm:flex-row sm:items-center sm:justify-between"><div><p className="font-heading font-semibold text-[var(--emerald)] dark:text-[#f4efe6]">Source code siap dikembangkan</p><p className="mt-1 text-sm text-[var(--text-muted)]">Project mengikuti struktur Vite + React + TypeScript dan siap diunggah ke GitHub. File cloud tersedia di Pustaka Media.</p></div><div className="flex flex-wrap gap-2"><Link to="/media" data-testid="about-media-link" className="inline-flex shrink-0 items-center justify-center rounded-lg border border-[var(--border)] bg-[var(--surface)] px-4 py-2.5 text-sm font-medium text-[var(--emerald)] hover:border-[var(--gold)] hover:bg-[var(--gold-soft)]">Pustaka Media</Link><a href="/jurumiyah-digital-source.zip" download data-testid="about-download-source-button" className="inline-flex shrink-0 items-center justify-center gap-2 rounded-lg border border-[var(--border)] bg-[var(--surface)] px-4 py-2.5 text-sm font-medium text-[var(--emerald)] transition-colors hover:border-[var(--gold)] hover:bg-[var(--gold-soft)]"><Download size={16} /> Unduh ZIP</a></div></div>
        <Watermark />
      </div>
    </div>
  );
}
