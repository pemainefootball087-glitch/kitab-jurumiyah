import { Download, FileArchive, FileAudio, FileImage, FileText, HardDrive, RefreshCw } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { apiGet } from "@/lib/api";
import type { MediaAsset, StorageStatus } from "@/types/media";
import { Button } from "@/components/ui/button";

const fetchMedia = () => apiGet<MediaAsset[]>("/media");
const fetchStorageStatus = () => apiGet<StorageStatus>("/media/status");

function formatBytes(bytes: number) {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

function AssetIcon({ type }: { type: string }) {
  if (type.startsWith("image/")) return <FileImage size={21} />;
  if (type.startsWith("audio/")) return <FileAudio size={21} />;
  if (type.includes("zip")) return <FileArchive size={21} />;
  return <FileText size={21} />;
}

export default function Media() {
  const mediaQuery = useQuery({ queryKey: ["media"], queryFn: fetchMedia, retry: false });
  const statusQuery = useQuery({ queryKey: ["media-status"], queryFn: fetchStorageStatus, retry: false });
  const assets = mediaQuery.data ?? [];

  return (
    <div data-testid="media-page" className="page-wrap">
      <div className="mx-auto max-w-6xl px-4 py-12 sm:px-6 lg:py-20">
        <div className="flex flex-col gap-6 border-b border-[var(--border)] pb-9 sm:flex-row sm:items-end sm:justify-between">
          <div><p data-testid="media-kicker" className="eyebrow">File & media storage</p><h1 data-testid="media-title" className="mt-3 font-heading text-4xl font-semibold text-[var(--emerald)] dark:text-[#f4efe6] sm:text-5xl">Pustaka Media</h1><p data-testid="media-description" className="mt-4 max-w-2xl text-base leading-7 text-[var(--text-secondary)]">Unduh source code, PDF kitab, gambar, dan audio pembelajaran yang telah diterbitkan oleh admin.</p></div>
          <span data-testid="storage-status-badge" className="inline-flex w-fit items-center gap-2 rounded-full border border-[var(--border)] bg-[var(--surface)] px-3 py-2 text-xs text-[var(--text-muted)]"><HardDrive size={14} className="text-[var(--gold-dark)]" />{statusQuery.data?.configured ? "Storage aktif" : "Storage belum aktif"}</span>
        </div>

        {mediaQuery.isLoading && <div data-testid="media-loading" className="mt-10 rounded-2xl border border-[var(--border)] bg-[var(--surface)] p-10 text-center text-sm text-[var(--text-muted)]">Memuat pustaka media…</div>}
        {mediaQuery.isError && <div data-testid="media-error" className="mt-10 rounded-2xl border border-dashed border-[var(--gold)] bg-[var(--surface)] p-10 text-center"><p className="text-sm text-[var(--text-secondary)]">Pustaka media belum dapat dimuat.</p><Button data-testid="media-retry-button" variant="outline" size="sm" className="mt-4" onClick={() => mediaQuery.refetch()}><RefreshCw size={14} /> Coba lagi</Button></div>}
        {!mediaQuery.isLoading && !mediaQuery.isError && assets.length === 0 && <div data-testid="media-empty" className="mt-10 rounded-2xl border border-dashed border-[var(--border)] bg-[var(--surface)] p-12 text-center"><FileArchive className="mx-auto text-[var(--gold-dark)]" /><h2 className="mt-4 font-heading text-xl font-semibold text-[var(--emerald)] dark:text-[#f4efe6]">Belum ada file diterbitkan</h2><p className="mt-2 text-sm text-[var(--text-muted)]">Admin dapat mengunggah source ZIP dan aset kitab melalui panel media.</p></div>}
        <div data-testid="media-list" className="mt-8 grid gap-4 md:grid-cols-2">{assets.map((asset) => <article key={asset.id} data-testid={`media-card-${asset.id}`} className="paper-panel flex items-start gap-4 p-5"><span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-[var(--gold-soft)] text-[var(--gold-dark)]"><AssetIcon type={asset.content_type} /></span><div className="min-w-0 flex-1"><p data-testid={`media-name-${asset.id}`} className="truncate font-medium text-[var(--text-primary)]">{asset.original_filename}</p><p data-testid={`media-meta-${asset.id}`} className="mt-1 text-xs text-[var(--text-muted)]">{asset.category} · {formatBytes(asset.size)}</p>{asset.description && <p data-testid={`media-description-${asset.id}`} className="mt-3 line-clamp-2 text-sm leading-6 text-[var(--text-secondary)]">{asset.description}</p>}</div><a href={`/api/media/${asset.id}/download`} data-testid={`media-download-${asset.id}`} className="inline-flex h-9 w-9 shrink-0 items-center justify-center rounded-lg border border-[var(--border)] text-[var(--emerald)] hover:border-[var(--gold)] hover:bg-[var(--gold-soft)]" aria-label={`Unduh ${asset.original_filename}`}><Download size={16} /></a></article>)}</div>
      </div>
    </div>
  );
}
